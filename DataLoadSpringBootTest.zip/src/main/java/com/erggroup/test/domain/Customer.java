package com.erggroup.test.domain;

public record Customer(String customerRef, String customerName, String addressLine1, String addressLine2, String town, String county, String country, String postCode) {}
